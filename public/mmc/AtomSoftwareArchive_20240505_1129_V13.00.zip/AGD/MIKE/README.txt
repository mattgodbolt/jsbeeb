Mike, the Guitar - Smells like...
=======================================
(c) copyright Sebastian Braunert and Uwe Geiken 2018


Story
=====
Mike,the little guitar, has a big wish: To play a solo! 
His favourite band is Nirvana, so he wants to perform "Smells like teen spirit"!
Attention: Jealous instruments and old "Ludwig van" want to stop his mission.
Avoid them, don't touch...
These grinches put the plectrums behind walls. But wait, they forget one plectrum. 
Soon Mike noticed: Everytime he plays the guitar with a plectrum somewhere else a wall breaks down and he can take the next plectrum.
Help Mike to collect 8 plectrums. After that lead him to the loudspeaker.
He will connect and play his favourite song.
Please note, Mike is low on memory. Collect Batteries to give him more strength, so you will lose a life, when the enemies get you, but you don't lose the game.
You only have to start form the first screen. But no worry, Mike keeps all the plectrums he collected so far.

Have Fun!!!!!

Controls
=========
Q - Up    
A - Down
O - Left
P - Right



Credits
========
"Mike, The Guitar" was created with 'Arcade Game Creator'from Jonathan Cauldwell and 'Musicizer' from David Saphier.

Music by
========
LaesQ
rnR T.A.D.7D9


Loading Screen
==============
Andy Green


Many thanks to
===============
*  thEpOpE (same procedure as always...i crashed the game fatally and he ressurected it)
* Ariel Endaraues, Andr� Luna Leao and Pedro Barata - the best Beta-Testers:-)
* George for making pressure to finish the bonus game;-)

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  MIKE.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  MIKE.DSK, Diskfile for emulators, to start the game, type *RUN"MGRUN"

AtoMMC version:

  MGRUN  = Basic introscreen
  MGSCR  = Titlescreen
  MGCODE = Gamecode

  To start the game, type: *MGRUN

