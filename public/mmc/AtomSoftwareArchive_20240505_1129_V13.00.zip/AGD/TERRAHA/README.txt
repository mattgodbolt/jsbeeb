Terrahawks:
-----------

EMERGENCY MESSAGE

ALIEN FORCES FROM ALPHA CENTAURI HAVE INVADED AND CAPTURED MARS STOP LEADER IS ANDROID "ZELDA" STOP ENEMY PLANS TO INVADE EARTH STOP PRIMARY OBJECTIVE TO DESTROY TEHRAHAWK ORGANISATION STOP

You are now a member of the TERRAHAWK organisation, a relatively small elite group of thoroughly trained specialists with highly sophisticated space craft and weaponry, specially set up to defend earth against the dangers from outer space, ZELDA, leader of the alien forces, is planning a surprise attack on the HAWKNEST, home base ot the TERRAHAWKS. It's up to you now to head off the danger and destroy the enemy. Life on earth depends on you!

Loading Instructions
Type LOAD�� and press ENTER
Press PLAY on your cassette recorder.
One loaded...

ZELDA makes her first, terrifying appearance!..
It is soon followed by a brief appearance of her mysterious mother-ship, launching eight flying saucers...

ZELDA's mother-ship.
ZELDA's flying saucers.

You only have a mobile turret at your disposal, equipped with a high energy beam gun. You cannot fire the gun while ZELDA is launching her flying saucers. You can move the turret with the joystick or the keys Z and X. Press the fire button or the space-bar to fire your high energy beam.

Mobile Turret

First battle phase
During the first phase of the battle the flying saucers only use relatively simple rockets, coming straight down to earth. You have to move your turret to avoid them but you can also destroy them with your high energy beam. When you do, you score 2 points. 
The saucers keep circling in close formation. Every time you succeed in destroying a saucer, you score 5 points.

Second battle phase
When you are fast enough you may succeed in destroying the entire flotilla of flying saucers. If you do. ZELDA returns to your screen. She is obviously upset and realises she has underestimated her opponent.
She calls on the mother-ship again and commands it to launch another squadron of flying saucers. This time she is confident that her evil efforts will succeed because those saucers are now equipped with rockets and special, red "Antimatter" mines! These mines will not come straight down but will actually follow your turret, to some extent at least, making it harder to avoid them. If you destroy one of those Antimatter mines in the air, you score 4 points.
You have hit and destroyed a flying saucer. It explodes in the air.
It will not be easy, but when you keep your head cool you may head off the danger again by destroying the 'lying saucers one after the other...

Third battle phase
When ZELDA appears on the screen again, she does not hide her emotions. She feels humiliated and her anger shows!
She orders her mother-ship to launch another squadron of flying saucers...
This time ZELDA's saucers will deploy the green Annihilators in addition to the rockets and Antimatter mines you have encountered earlier, it's a lethal weapon that will not explode immediately when it hits the earth surface. Instead it will slide towards you. They are quite treacherous and you will have to watch out. A good solution of course is to try and destroy them on their way down. If you do. you score 8 points!
You really have to be pretty good lo survive this ordeal but then, after all you are a member of the elite TERRAHAWK group. So let us assume you actually succeed in shooting down all enemy spacecraft...

Fourth battle phase
ZELDA is obviously desperate and infuriated when she comes to the screen again to overlook the situation in disbelief. She realises that the time has come for her final weapon...
ZELDA's fourth squadron carries the terrifying purple "Nucleonic Space Mines", along with the other weaponry you have been confronted with already, They have the unpleasant habit to zero in on their target! Things are getting pretty hectic at HAWKNEST. You will have to act fast and every mistake can easily be fatal! If you hit a Nucleonic space mine with your high energy beam, you score 16 points.

Fifth and following battles
If you live through the fourth invasion effort, you have really proven yourself to be a true member of the TERRAHAWK organisation. But unfortunately it isn't over yet. ZELDA returns again full of hatred and is determined to take HAWKNEST at any cost. She keeps sending in new squadrons. They attack more fiercely with every new wave...

End of battle
The battle ends when your turret is hit and destroyed.

Next Invasion
Another invasion effort starts immediately, going through the same cycle of battle phases as described above. 

Competition play
You can give it another try yourself or turn the hand control over to a friend to see who stands up best to ZELDA's evil forces.

Scoring points
2 points for destroying a cluster of rockets
(see battle phase 1)
4 points for destroying an Antimatter mine
(see battle phase 2)
5 points for destroying a flying saucer
8 points for destroying an Annihilator
(see battle phase 3)
16 points tor destroying a nucleonic space mine
(see battle phase 4)

Good shooting! The eyes of the world are upon you!

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  TERRAHAWKS.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  TERRAHAWKS.DSK, Diskfile for emulators, to start the game, type *RUN"TERRUN"

AtoMMC version:

  TERRUN  = Basic introscreen
  TERSCR  = Titlescreen
  TERCODE = Gamecode

  To start the game, type: *TERRUN

