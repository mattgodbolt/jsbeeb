Mr. Vintik:
-----------

Already this week is starting with a bang for ZX Spectrum owners, as another ZX Spectrum game has appeared that will really put your mind to the test. This is ' Mr.Vitnik ' by Termojad; a new ZX game in Arcade Game Designer that requires you to collect all the blue coloured points to complete the level, and finally to rescue your lady friend from that giant yellow robot like creation.

To gather all the points needed, you need to move your little white man across each blue circle until they are completely filled. Once all of them are filled in each level, you move on to the next. The problem is throughout each level are enemies that when touched will kill you instantly. The only way to kill these enemies is by collecting the bonus's scattered about and killing them as soon as possible, because if you don't, it's going to be VERY difficult for you to complete the game, oh and believe me these enemies are smart.  For what it is worth this is a very challenging but fun game to play, if you have kids of a very young age, don't even let them play this as they may throw a right paddy!

Controls:

  Q   - Up
  A   - Down
  O   - Left
  P   - Right
SPACE - Jump

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  VINTIK.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  VINTIK.DSK, Diskfile for emulators, to start the game, type *RUN"VINRUN"

AtoMMC version:

  VINRUN  = Basic introscreen
  VINSCR  = Titlescreen
  VINCODE = Gamecode

  To start the game, type: *VINRUN

