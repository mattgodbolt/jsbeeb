The Incredible Shrinking Professor:
-----------------------------------

The Plot
Bio-Chem Research isn't all fun...

At Revanox Bio-Chem Research (the pharmaceutical and beauty division) the day started like any other for Professor Peter Poldark. The test rabbits where given facials and some great lipstick to wear, but before long all that fun was about to come to a crashing halt. Sirens blare and from the adjacent Military division explodes a swarm of micro-bot Wasps, Lipstick missiles and genetically modified spider/ants! not to mention the intelligent putty (charmingly called Nigel) and the mini-nanite clouds and they invade your lab!! Surrounded by these pests you grab at anything to stop yourself falling over... unfortunately you grab a tray of experimental chemicals which drench you in a myriad of untested quantities. You lose consciousness. 
When you wake you find yourself lying on the desktop and to your horror you are only an inch high!!! Your only hope is your experimental Embiggan Totalis Elixir compound. You left a sample on the top shelf! Its only a catalyst though, you need some ingredients to complete the potion! 

Hurry though, you don't feel well and you occasionally change your appearance!! This might be permanent if you're left in flux too long!!

?

Find those ingredients and the elixir, Professor! The lab needs you!

How to Play
Controls are simple.  Z - Left  X - Right  M - Down  K - Up  L - Jump  SPACE - Use/Pickup

or Joystick: Left/Right/Up/Down , FIRE to Jump and SPACE - Use/Pickup

Note ZX Spectrum VEGA users: Download the VEGA version and use the KEMPSTON option.

Controls: Up/Down/Left/Right  F - Jump  S - Use/Pickup

Traverse the screens and collect the ingredients necessary to complete the Embiggan formula. These ingredients are 3x Blue Growth Pills (Triangular Blue), 2x Solidification Pills (Round Green) and a Conductive Crystal (White diamond shaped).
Find all these and then go to the Embiggan Totalis Elixir and bath in it to regain your size!!! 

?

Other things to know.... You can carry one object at a time (you're only tiny remember). This is shown in the top left corner of the display (1). If you're already carrying an object and you pick up another it will drop your current item where you stand. Find a pulsing '?' (2) and this is where you need to stand to USE a specific carried item. 
When you pickup ingredients or extra lives (hearts) they will be display on the righthand side of the screen (3).

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  TISP.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  TISP.DSK, Diskfile for emulators, to start the game, type *RUN"TISRUN"

AtoMMC version:

  TISRUN  = Basic introscreen
  TISSCR  = Titlescreen
  TISCODE = Gamecode

  To start the game, type: *TISRUN

