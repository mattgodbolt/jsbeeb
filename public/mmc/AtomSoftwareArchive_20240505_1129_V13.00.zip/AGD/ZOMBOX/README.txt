THE UNOFFICIAL ZOMBO'S CHRISTMAS CAPERS:
----------------------------------------

He's back, and this time it's Christmas! Zombo returns in this brand new completely unofficial game for the Sinclair ZX Spectrum! Now featuring 76% less game-breaking bugs than the first game in the series!

What's that you say? You can't be bothered fiddling with emulators? Now you don't have to, as it comes bundled with a version that'll run on your PC without having to set anything up!

THE PLOT

Centuries of overwork and stress have finally taken their toll - Santa� has suffered a psychotic break and gone missing from his workshop in North Renfrewshire. The Government� have tasked Zombo� with tracking down Mr. Claus� and retrieving the gifts for all the good little boys and girls�. Luckily, the naughty list is rather long these days, so he only needs to find a total of six presents.

GAMEPLAY

You must retrieve 6 presents and defeat the end of game baddy to win. Colour coded keys are scattered around, as are several other items, some of which are useful, others of which are not, but there's a Shootybang 2000� somewhere which'll probably come in handy, (please bear in mind that the Shootybang 2000� can only fire horizontally).

CONTROLS
Kempston Joystick
Sinclair Joystick
Keyboard
Q - Up
A - Down
O - Left
P - Right
SPACE - Fire
H - St. Bernard's Watch (Pause)
3 - Instantaneous Death Button (Quit Game)

Alt & F4 � Quit bundled emulator

BADDIES

Killer Sprout - Bounces, requires 1 shot to kill.

Yellow Snowman - Moves erratically, requires 1 shot to kill.

Nutcracker Soldier - Moves vertically, unkillable.

Scrooge-Elf - Moves horizontally, unkillable.

Killer Xmas Tree - Follows player, requires multiple shots to kill.


Zombo and Zombo's Christmas Capers are completely unofficial, not-for-profit fan-games by Malcolm Kirk.
Programmed in Jonathan Cauldwell's Arcade Game Designer.
Zombo� Rebellion A/S, � Rebellion A/S.

Created in conjunction with the 2000AD MESSAGEBOARD ADVENT CALENDAR 2016�.

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  ZOMBOX.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  ZOMBOX.DSK, Diskfile for emulators, to start the game, type *RUN"ZOXRUN"

AtoMMC version:

  ZOXRUN  = Basic introscreen
  ZOXSCR  = Titlescreen
  ZOXPAN  = Panel
  ZOXCODE = Gamecode

  To start the game, type: *ZOXRUN

