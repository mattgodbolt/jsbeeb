Steel Jeeg:
-----------

- � 2018 FRANCESCO FORTE - ALL RIGHT RESERVED - THIS IS A FREE GAME 
THE GAME - EVERY COMMERCIAL DISTRIBUTION WITHOUT THE EXPRESS CONSENT OF ITS AUTHOR IS STRICTLY FORBIDDEN
- AUTHORED WITH ARCADE GAME DESIGNER 4.7 - � 2017 JONATHAN CAULDWELL
- BASED ON "STEEL JEEG" TV ANIME, 1975 - � TOEI ANIMATION CO. LTD
- THANKS: JONATHAN CAULDWELL (AGD), PAUL JENKINSON (AGD TUTORIAL), ALESSANDRO GRUSSU (TECHNICAL SUGGESTIONS ABOUT CONTROLS REDEFINING), ENCIROBOT.COM AND MECHAWIKIA.COM (SG TV ANIME INFORMATIONS)

THE GAME
--------
Jeeg Robot invaded the Yamatai kingdom to destroy his mortal enemies: Queen Himika and the Dragonlord. To do this, however, he'll have to face the fearsome Haniwa monsters along the caves labyrinth of the underground realm. He'll have to find some objects: the Jeeg bazooka, indispensable to kill the Queen and the Dragonlord, and the levers that open the passages that lead to the respective caverns.  Jeeg has available a starting energy equal to 255. Once this energy is exhausted, the game will end before Jeeg has completed his mission.  

THE WEAPONS
-----------
At the beginning of the game, Jeeg owns the following weapons: magnet power, spin storm, magnet rope, Jeeg beam and knuckle bomber, which serve to destroy the Haniwa monsters. The Jeeg bazooka is in one of the labyrinth caverns and can only be used against Himika and the Dragonlord. Each weapon will only be effective against a certain group of monsters. The weapon to be used will be selected by a special key and activated by the FIRE button. Regarding the Jeeg bazooka, it will be automatically selected in the Queen and Dragonlord caverns.

HANIWA MONSTERS
---------------
RED monsters can only be destroyed using the magnet power, but to do this Jeeg will have to approach them and this will result in a possible energy losing. In fact, EVERY CONTACT WITH ALL HANIWA MONSTERS CAUSES AN ENERGY LOSING.
WHITE monsters can be destroyed with one of the other available weapons  and you'll have to find out which of these will be effective against a certain monster. However, a single hit won't be enough for one of these monsters... (see TV anime episode 22). Jeeg will even lose energy when he is hit by monsters' shots.

SPHERICAL BOMBS
---------------
These are bombs with which you have to avoid contact, otherwise they'll  explode (energy losing).

QUEEN HIMIKA AND DRAGONLORD
---------------------------
You have to hit them at least 5 time to destroy them. But pay attention: A CONTACT WITH THEM WILL END THE GAME.

LEVERS
------
There are two levers in the caves labyrinth: the first opens the passage that leads to the Himika cavern, the second (which you will find in the caverns following the Queen's cavern) opens the passage that leads to the Dragonlord cavern.

SCORE
-----
RED MONSTERS: 3
WHITE MONSTERS: 1
QUEEN AND DRAGONLORD: 5

GAME CONTROLS
-------------
It is possible to redefine the game controls.
Default controls are:
I - LEFT
O - RIGHT
Q - UP
A - DOWN
P - FIRE
N - CHANGE WEAPON

Enjoy yourselves!

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  STEEL.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  STEEL.DSK, Diskfile for emulators, to start the game, type *RUN"STERUN"

AtoMMC version:

  STERUN  = Basic introscreen
  STESCR  = Titlescreen
  STECODE = Gamecode

  To start the game, type: *STERUN

