MagicAble:
----------

Written by Packobilly 

In the beginning there was nothing. 
Nothing except Magic. 
Peace and balance reigned in Arnaroth. 
The sixteen Dark Talismans were kept in the Cauldron of Providence, and thus everything remained in its place. 
Until now… 
The Forces of the Underworld have scattered the Talismans throughout the Kingdom of Arnaroth, plunging everything into utter chaos. 
Four, in The Haunted Forest. 
Four, in The Scary Dungeon. 
Four, in The Cursed Castle. 
And four others, in The Doomed Cave. 
And to make matters worse, you, the fat old wizard Able, guardian of The Old Nest, are the one designated to return them to The Cauldron of Providence.
But beware, for the Dark Talismans to take effect, they can only be deposited one by one in The Cauldron and in due order. 
Also, Magic is weak in you, so you will not be able to invoke spells at your whim; and such spells have no effect on all creatures. 
You will find out which ones are immune to your decrepit magic, and which ones succumb to your spells. 
And one more thing; remember that your old bones are not for many jogs, so you can only jump using the Magic Stones that you once distributed throughout the Kingdom to help you move around it. In those days, you used them to reach the mistletoe in forest or to obtain stalactite powder for your spells. Anyway, nowadays those Magic Stones are going to be useful. 
There is nothing left but to wish you luck on your journey (you will need it) and may the Power or the Ancient Warlocks of the Kingdom of Arnaroth be with you… 

Controls:

 O  - Left
 P  - Right
 Q  - Jump
 H  - Pause
 G  - Quit
SPC - Use object
Special Thanks to 

Johnathan Cauldwell, for the incredible tool. 
Alessandro Grussu, for his tips. 
David Saphier and Allan Turvey, for that magic code. 
Asteroide ZX, for his help. 
Sergio The PoPe, for that knowledge. 
THANK YOU ALL.

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  MAGICABLE.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  MAGICABLE.DSK, Diskfile for emulators, to start the game, type *RUN"MARUN"

AtoMMC version:

  MARUN  = Basic introscreen
  MASCR  = Titlescreen
  MACODE = Gamecode

  To start the game, type: *MARUN

