DEAD ZONE by PCNONOGames:
-------------------------

Earth�s main cities are being invaded by UFOs that abduct all
living beings they find. Every place they raze become a DEAD ZONE.
You must save the population of the cities and prevent
them from being abducted by UFOs. To do this you must shoot
them and kill them all.

CONTROLS

1 - KEYBOARD (QAOP-SPACE)
2 - KEMPSTON
3 - SINCLAIR

VERSION - CONTROL POINT

In the checkpoint game version, every time you surpass
one level, the mode control point will be activated, if
you lose the game, when you restart another, you start from the
point of control, that is, you will start from the level where
You lost the game. In a way, this game mode is the
easier if you want to kill all the UFOs !!!!

VERSION - SURVIVAL

In the survival version, every time you lose the game,
You will have to start from the beginning, from the first level.
This game mode is the most difficult, and is only suitable for
that they like the challenges or the lovers of the old school !!!

CREDITS

Address: Antonio Rom�n Mart�n (Nono)
Programming: Antonio Roman Mart�n
Graphics: Juan Jes�s Ligero (J.J) and Antonio Rom�n
Music: Sergio Beyker
Assistance in Advanced Programming (AGD): Sergio thEpOpE
T�ster: David Enrique (the namesake), Juan Jes�s Ligero, Ana Rodr�guez
Translation: Marina Rom�n Robledo, Juan Jes�s Ligero
Special Thanks: Jonathan Caudwell, Javi Ort�z, Allan Turvey, Jaime Grilo,
Alessandro Grussu

LINKS

web: www.pcnono.es
twitter: @PCNONOGames
Facebook: @PCNONOGames
email: nonoroman4@gmail.com

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  DEADZONE.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  DEADZONE.DSK, Diskfile for emulators, to start the game, type *RUN"DZRUN"

AtoMMC version:

  DZRUN  = Basic introscreen
  DZSCR  = Titlescreen
  DZPAN  = Panel
  DZCODE = Gamecode

  To start the game, type: *DZRUN

