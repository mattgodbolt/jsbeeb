LUPO ALBERTO:

Another day another ZX Spectrum game from Gabriele Amore, and this one is a very difficult platformer titled ' LUPO ALBERTO ', which according to the developer is similar to Albert the wolf but has better graphics and simpler gameplay. In this game you play as Lupo and through each of the three stages must build a stair of bricks from the cyan brick case to reach Marta the hen, who you are very much in love with.

Now the aim of the game is out the way, I'll be honest here. With all the games I've played on the ZX Spectrum, this one almost made me throw my keyboard out the window. It was incredibly frustrating to play, as for some reason the controls were not as responsive as I'd have liked and when the first enemy touches you, it constantly bounces you out of the way. This is especially annoying trying to place the brick in the correct location, only to get bounced into one of the pond areas and end up having to restart the game. Sufficed to say I never got past the first level, even if the video above makes it look like a simple task.

Do note however that this is a very small game, so that's probably why it isn't very easy, plus the fact it has no music and limited sounds. As for a positive, I do like the character designs and especially the idea about building bricks to reach a loved one, it's just got a long way to go before I'd consider it a good game.

Controls:
Q-Jump 
A-Down
O-Left
P-Right
M-
1-
2-
