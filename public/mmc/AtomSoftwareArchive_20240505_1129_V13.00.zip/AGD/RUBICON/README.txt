Rubicon:
--------

The Plot
Your right of passage to adulthood has arrived!

You are NYM. Your last day of childhood has arrived and as tradition dictates, you must undergo a right of passage. You must cross the Rubicon maze. A fiendish labyrinth that will test your abilities. Find the five Scrolls of Knowledge. Find the three Crowns of Wealth. Find the Ring of Argus. Find the Amulet of Light so that you can pass the gate keeper and find you true love. 

?

BE BRAVE NYM, BE BOLD!

How to Play
Controls are simple.  Z - Left  X - Right  K - Up  M - Down  L - Activate Shield .

Space Bar - Toggle Music On/Off while playing.

Press R to redefine the Keys (except Space Bar).

or Joystick: Left/Right, Up/Down and FIRE for Shield.

Note ZX Spectrum VEGA users: Download the VEGA version and use the KEMPSTON option.

Controls: Up/Down/Left/Right  F - Shield, S - Music On/Off toggle.

Locate and collect 5 Scrolls, 3 Crowns, Ring of Argus and the Amulet of Light. You will also come across Doors (Diamond Shaped) there are keycards that you must be holding for them to disappear. 

Once you have everything go to the Gate Keeper room. He will have gone if you have them all. If he remains, it means you have not collected everything.

You will also find Shields. You can carry only one at a time. Once activated it will last a few seconds.... making you immune to all energy sapping creatures. Beware the shield will not protect you against the instant kill enemies. Use it wisely. 

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  RUBICON.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  RUBICON.DSK, Diskfile for emulators, to start the game, type *RUN"RUBRUN"

AtoMMC version:

  RUBRUN  = Basic introscreen
  RUBSCR  = Titlescreen
  RUBCODE = Gamecode

  To start the game, type: *RUBRUN

