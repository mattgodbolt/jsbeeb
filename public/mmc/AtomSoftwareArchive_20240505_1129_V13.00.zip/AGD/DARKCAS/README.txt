Dark Castle:
------------

Everyone is looking for his share of adrenaline… 
Bob is ordinary country boy. He is working on a farm everyday and he works without cease. 
One day, he thought that he is fed to the teeth! Bob has made a decision to digressed from his work days. 
But how to do that? Suddenly it dawned on him! 
He recalled a old castle nearby farm. The Castle is very interesting place, because some say that the castle immersed in witchcraft. Others say that ghosts live in castle. There is an opinion that man can stay in castle forever. 
Candles are burning in old castle every night. It is a fact. 
Bob takes a matchbox by nightfall, he going to find share of adrenaline 

Game purpose:

In pursuit of adrenaline Bob has to withstand all the dangers of the dark castle, and he hasn't to stay there forever… 
Stairs should help you move to next level. 
Help Bob get to the stair.

Control keys: 

Keyboard: O, P, SPACE, Z, R.
Kempston joystick
Sinclair joystick

Specific game:

Matches:
You can use matchbox for lighting rooms in castle. You must remember all in lit room, because matchbox use once on level. 

Time:
The maximum time spent in the castle - 60 minute! If Bob will stay in castle longer, that he can stay there forever… 

Ghosts:
Ghosts are different in castle: 
- Moving: - small mouth, increasing second, - big mouth, increasing minute. 
- Fixed: - picks up a life. 

Traps: 
In some rooms has been a traps, of which you can’t go out. If this happens, that press – R.
You'll restart the level, the total time game will be increased with 5 minutes. 
Herewith you keeping your live, be careful! 

Elevators: 
Elevators going only up simultaneously. Pay attention to it! 

Lives: 
In the game you can die only 5 time. Keeping your lives! 
 
THANKS: 
- Maxim Nikitin aka WBR^NOT-Soft - beta – testing. 
- Galina Buldakova - text translation. 
- Evgeny Kolesnikov ака Buddy^ERA Creative Group - saver for the game. 
- Sergey Sirotenko aka Blade - finalization of the material, AY music in the game. 
- Oleg Origin aka Oleg Origin – poster for the game. 
- Jonathan Cauldwell aka Jonathan – Arcade Game Designer (AGD) 

Enjoy the game!
SPECTRUM FOREVER! 

Kas29 
http://newgamezx.jimdo.com

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  DARKCASTLE.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  DARKCASTLE.DSK, Diskfile for emulators, to start the game, type *RUN"DCRUN"

AtoMMC version:

  DCRUN  = Basic introscreen
  DCSCR  = Titlescreen
  DCCODE = Gamecode

  To start the game, type: *DCRUN

