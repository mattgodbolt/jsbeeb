THE LOST ISLAND:
----------------

AUTHOR:	kas29
YEAR:	2013

STORY
------------------------
A renowned professor of archeology and biology, figured out the location of a legendary island and rushed off to investigate.
After two weeks with no news from him...you, the most daring of his students, are told to look for him.
During the search, you will face the local flora and fauna, to stay alive in this island...
Do not fall into traps, find hiding places, collect yellow cookies to restore your energy level,professor loves cookies so much that he's scattered lots of them throughout the island.
Once you find the professor, come back to the ship safe and sound and sail home.

GAME CONTROL
------------------------
O - Left
P - Right
Q - up (jump)
A - Down
R - restart the game
space - take an object

TIPS
------------------------
Every third cookie increases your energy level.
Look for hiding places
http://www.worldofspectrum.org/forums/showpost.php?p=693306&postcount=61
 
CREDITS
------------------------
Thanks for the support: Jonathan Cauldwell, 10loadgameplay, nra, goodboy, scl ^ mc, Rindex, AAA, TREFI!!!
Special thanks for the help Blade!!!!!

If you run in 128 mode will be AY music when in the 48 the beeper.

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  LOSTISLAND.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  LOSTISLAND.DSK, Diskfile for emulators, to start the game, type *RUN"LIRUN"

AtoMMC version:

  LIRUN  = Basic introscreen
  LISCR  = Titlescreen
  LICODE = Gamecode

  To start the game, type: *LIRUN

