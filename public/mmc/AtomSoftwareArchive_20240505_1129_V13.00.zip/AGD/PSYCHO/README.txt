Psycho Santa:
-------------

Wishing you a very merry Christmas and a happy, healthy and prosperous 2024!!

Evil Santa has sent his Elfs to turn people into snowmen to keep them frozen and blind to the truth that he has been taking credit for mothers and fathers hard work and keeping the people away from the teachings of his arch nemesis, Jesus, for generations.
You set out to defrost the people, guide them to freedom and take out Evil Santa!

Psyqo Santa will run on any device via a ZX Spectrum emulator
If you enjoy Psyqo Santa you may also enjoy Ziona Quest X

CONTROLS

Keyboard - Q=UP , A=DOWN, O=LEFT,  P=RIGHT,  SPACE=FIRE
PRESS 'M' to switch between SNOWBALLS and FLAMETHROWER
H= PAUSE GAME

HOW TO PLAY

Defrost SNOWMEN with your FLAMETHROWER then guide them to the CAVE using your SNOWBALLS
SNOWMEN drain your ENERGY on contact
When ENERGY is OUT you must STAND STILL to RECHARGE
Be careful not to shoot PEOPLE with your FLAMETHROWER as they will be set on fire and will kill you on cantact - Hit burning people to 'Re-Frost' them.
Santa's ELFs turn 'De-Frosted' back into SNOWMEN. 
ELFs will KILL YOU on contact
ELFs can be temporarily DISABLED with FLAMES
RECHARGE your ENERGY by TOUCHING DISABLED ELFs

Clear 5 levels then head to the Grotto for a final snowdown with Evil Santa
We hope you have a great time with our wee special Christmas release!!
Special thanks to NQ for provinding Psyqo Santa's beautiful soundtrack


Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

  Q   - UP
  A   - DOWN  
  O   - LEFT
  P   - RIGHT
SPACE - FIRE

  M   - Switch between SNOWBALLS and FLAMETHROWER
  H   - PAUSE GAME

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  PSYCHO.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  PSYCHO.DSK, Diskfile for emulators, to start the game, type *RUN"PSRUN"

AtoMMC version:

  PSRUN  = Basic introscreen
  PSSCR  = Titlescreen
  PSCODE = Gamecode

  To start the game, type: *PSRUN

