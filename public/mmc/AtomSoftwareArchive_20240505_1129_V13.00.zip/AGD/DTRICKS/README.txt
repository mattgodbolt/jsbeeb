Dark Tricks.

Story:
The Pumpkin master has decided to turn good and rid the world of all evil antics on Halloween 

night using his new found power to affect the real world, the golden pumpkin. One Skeleton by 

the name of Brittle has set out to remove the pumpkin master of the golden pumpkin and end 

this once and for all, help Brittle on is quest this Halloween night.

Keys:
o,p and space or joystick

Instructions:
Collect as many objects as possible or just go for it and speed run the whole thing.

Thanks:
Binman For Help with release and some artwork, Jonathan for AGD, Paul J for the AGD video 

tutorials, Dominic and Lily for putting up with me doing this and testing.

Controls:

  Q  - up
  A  - down
  O  - left
  P  - right
SPACE- jump

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

 DTRICKS.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  DTRICKS.DSK, Diskfile for emulators, to start the game, type *RUN"DTRUN"

AtoMMC version:

  DTRUN  = Basic introscreen
  DTSCR  = Titlescreen
  DTCODE = Gamecode

  To start the game, type: *DTRUN

