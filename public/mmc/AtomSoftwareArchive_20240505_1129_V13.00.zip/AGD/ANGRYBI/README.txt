Angry Birds: Opposition:
------------------------

How many of you remember that highly addictive game whereby you used to fling birds at collapsible objects to knock pigs out of the way? Well I do and it was the gaming fad for the time ' Angry Birds ', which isn't on anyone's mind right now as it's mostly Pokemon Go. But what if we could take Angry Birds and turn it into a shooter for the ZX Spectrum? Welcome to ' Angry Birds (Opposition) ' by kas29.
Unlike the bird flinging antics from the original, Angry Birds (Opposition) is completely different. In this one you play as the pigs and must shoot down the birds flying across the screen to capture their eggs. If you miss one, the eggs are delivered and the cart at the bottom moves towards the enemy side but if you shoot an angry bird, the cart moves to the right and your score goes up.
So the aim of the game is simple, get that cart as far to your piggy side as possible and keep doing this until the next level. But be warned, it isn't a bad game at all, but your adrenaline levels will go up as with each success the birds get quicker and you've got to be very precise with your shooting...

Good luck ZX Spectrum owners!

Control keys:

  T   - Time
  P   - Pause
SPACE - Fire
  E   - Exit

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  ANGRYBIRDS.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  ANGRYBIRDS.DSK, Diskfile for emulators, to start the game, type *RUN"ABRUN"

AtoMMC version:

  ABRUN  = Basic introscreen
  ABSCR  = Titlescreen
  ABCODE = Gamecode

  To start the game, type: *ABRUN

