Bubble Frenzy:
--------------

Instructions

The bubble factory has gone into meltdown and as the night watchman you must make sure that all the escaping bubbles are burst so that they don't present a threat to the workers coming in for their early morning shifts.

Normally your nights are very easy, watching television or reading the newspaper but not tonight ! Tonight all hell has broken loose in the factory and the bubbles are flying everywhere. This could lead to a potential health safety nightmare and your job will be on the line if you don't deal with this situation quickly.

Burst all the bubbles in each area in order to move on to the next but beware, somewhere in the factory you will discover the culprit (or culprits) responsible for this dire act of industrial sabotage and you will have to dispose of them with extreme prejudice.

Use your trusty hammer to smash out parts of the factory floor for the bubbles to fall through until they reach the failsafe bubble bursting mechanism at the very bottom (which you must first expose by breaking through to it from the bottom floor). Be careful you do not fall into this area yourself, as it is also a human bursting area ! Also, be mindful that removing certain parts of the floor will hinder or impede your progress. smash strategically !

To destroy an area of the floor, simply stand in front of t and press the action button. This will smash the section out, leaving a gap that bubbles and any other troublesome individuals you discover will fall through.

Use the blue lifts to make your way up through the factory areas. They are one way lifts so you will have to bash holes In the floor if you want to get back down again, but be aware of where you're going to land..

Also watch out for the bubble relocation mechanisms on some levels, marked as red and yellow barriers. if a bubble touches them it will be moved up towards the top of the factory again. However, these are not meant for humans and will kill if you so much as touch them.

The brick walls found in some levels can be bashed down by striking them from above.

As already mentioned, it is possible that, due to your own incompetence, you will destroy an area to the extent that you can no longer access the necessary platforms rewired to clear that screen. In this case you will have no option but to end your own life rather than face the indignation of vocational failure !

Find more titles from this author onhis Facebook page
GABAM's ZX SPECTRUM GAMES
WWW BUMFUNGAMING.COM

Controls:

O - LEFT
P - RIGHT
M - DIG

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  BUBBLEFRENZY.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  BUBBLEFRENZY.DSK, Diskfile for emulators, to start the game, type *RUN"BFRUN"

AtoMMC version:

  BFRUN  = Basic introscreen
  BFSCR  = Titlescreen
  BFCODE = Gamecode

  To start the game, type: *BFRUN

