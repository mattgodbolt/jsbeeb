Higgy 2 The Wrath of McMania:
-----------------------------

"Here, Tichi." Ian Higton ripped open a cat food pouch, causing his hungry kitty t scale up his leg.
"Ow!" Ian yelped, as claws met calf. "Maybe jorts aren't the best clothes for cat-feeding... No. Can't be," he mused as he detached Titch. "Jorts are simply the best, better than all the rest."

"Jorts won't save you!" Ian's namesis crashed into the room. It was the wrestling heel, Mr McMania. Oiled up to the nines, he cracked his knuckles.

Titchi hissed and launched herself at McMania. He snatched her out of the airr, then issued a challenge: "Higton, you prick! Try to rescue your cat from my golden castle in the sky. My minions will make short work of you an your jorts!"

"How will I get there? It's not like there's a bus!" Ian protested. But McMania had scarpered.

Will Ian be able to save his cat? You decide.

Schnaffle throughover 20 screens (so ... 21 then) of ZX Spectrum action as Ian Higton explores the streets, sewers, desert and even a floating golden castle in the sky in order to save his cat Titch from the bizarre and violent Mr.McMania.
It's a sausageey good time!

Controls:

  Q   - up
  A   - down
  O   - left
  P   - right
SPACE - Jump

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  HIGGY2.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  HIGGY2.DSK, Diskfile for emulators, to start the game, type *RUN"HIGRUN"

AtoMMC version:

  HIGRUN  = Basic introscreen
  HIGSCR  = Titlescreen
  HIGCODE = Gamecode

  To start the game, type: *HIGRUN

