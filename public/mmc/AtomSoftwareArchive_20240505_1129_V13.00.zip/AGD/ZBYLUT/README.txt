*******************************************************************************
PL title: 
Zbylut Owrzodzie? w kamiennym, kurwa, zajebanym czarcim kr?gu.

ENG title: 
Crapbert Buttslut in the muthafuckin' damn stone-circle of the devil.
*******************************************************************************

A GAME MADE IN April-August 2012 by HOOY-PROGRAM 
for ZX Spectrum 48K with AY-interface.
Based on AGD 3.

Controls: 
- Keyboard (OP/SPACE)
- Kempston Joystick

The game has 34 levels of HELL. ;) 
You have to avoid devils and collect all devil-stones and drink all bottles of vodka in each level. 
And finally - You have to escape from hell. ;) 

HELLBOJ: coding, linking, cracking and so on. 
YERZMYEY: idea, screenplay, graphic, levels, AY-music (in-game).
Mister(ious) Beep: beeper music (main title).
Jonathan Cauldwell - remarks and moral support. 


*************************
Entire game works on ZX Spectrum 48K (with AY-interface for in-game music). 
*************************



http://hooyprogram.republika.pl/

The game has been made for WAPNIAK 2012 party (the game-compo).



              _________________________________________________________ 
              |                  From HOOY-PROGRAM!!!                 |
              |-------------------------------------------------------|
   
      Greetings (use searching to find Your nickname OR your group name possibly) - 

- KAZ
- ZIUTEK
- KASSOFT
- JACEK MICHALAK
- CAT-MAN
- Two Bears Software (HACKER MICHELLE & FRANK BROWN)
- SEAN ADAMS
- RAFII SOFT
- MIVA
- BILL GILBERT
- ANDY
- BR0MBA
- SZAFRAN
- KICIA
- WISEMAN
- SEBEK N.
- HACKER CHRIS
- Mr Bob & Hannah
- Sergey Bulba
- The Lords
- Zbigniew N. (Zoon)
- JACK DAVIS
- The Players
- MAC
- AMIGO (hi!!)
- AMST
- ICE MAN
- Monster
- ICABOD ;-)
- DIZZY
- MIKROPOL
- TDM :)
- 4TH DIMENSION
- A. KWIATKOWSKI
- R.I.P.
- HACKER DEMON
- SAPOSOFT (DANIEL MARTANOVIC)
- NORO
- POOLPET
- SABE
- BUSY SOFT (SLAVO LABSKY)
- TINBIN HACKER (CRAIG EADES)
- Total Eclipse (STEVE ANDERSON & GARETH JAYNE)
- MAT
- HACKER DANSOFT
- X-AGON ;-)
- TRIEBKRAFT
- Spectrus Adventure Software (MALY)
- SIR SAM
- WOS (makers and the Forum guys)
- GAPA
- PESOFT LTD
- MAREK
- JOHN (JASIU BLEBLEBLE [???!!])
- DEONSHEE
- C-JEFF ;-)
- ATE BIT
- KAMILLO
- HACKER PSV
- PHONEX
- SKRJU
- HACKER JUNIOR
- AXELSOFT
- RAF
- S.S CAPTAIN
- WODZU (a wlasciwie obydwaj!!)
- BZYK
- TAXI DRIVER
- FAT RAF
- HACKER KILLER
- VELESOFT
- BAZOOKA
- JOHN DALTHON
- P.P. MINIO
- CRUSHER
- MALIN
- STVE
- YANKES
- HELLBOI (the Lazy Bastard ;-) )
- MARAS
- MISIU
- CRAZY MAN
- CPU
- MACIEJ WRONSKI
- SZPERACZ
- BRUNO
- SUNGAM
- RMC
- MUZ-MAN
- TARZAN BOY
- ROBY
- PCV
- DI GI
- MACHUL
- PETER & PAUL HATCHETS
- ADAM HODSON
- NAGEL
- LEONCIO
- Mr Hangman
- FAT PETER
- G. A. LUNTER
- WoMo-Team
- ZACK
- FUXOFT
- T.E.A.M SOFTWARE
- DATAsoft (now: BREEZER) 
- RST 7, (R)SOFT, VAG, SLAYER, BEGINER, (M)SOFT
- VAR
- MARK
- TYGRYS/GDC ;-)
- CONRADORRE
- FISHBONE CREW and Breeze :) 
- THE INFAMOUS BLOOD
- WORLD EYES group
- EXTREME group (subgroups: BEERMANS, MAGIC SOFT, MEGACODE, SPEED COMPANY)
- PROGRESS
- E-MAGE
- TANKARD
- HACKER JIM GOER
- PENTAGRAM
- CYREHL OWL
- K3L
- DIGITAL REALITY
- DREAM MAKERS
- AXCO
- MR. CRACKPOT
- KOOLPHONE
- AGENT X
- DOC. R
- ZERO (hi, Zhenya!! :-) ) 
- CODE BUSTERS
- SEAMANS
- DMS
- LAVE SOFTWARE
- EXCESS
- NOUMENON TEAM
- MQM
- REACTION
- FLASH
- NAUGHTY CREW
- TGM CREW
- 7 GODS
- JORDAN & all EXODUS
- ILLUSION (hi RADXCELL ;-) ) 
- 3SC
- EXIN
- PHANTASY 
- X-TRADE
- BLACK SHARK
- UNITED MINDS
- TORNADO
- TECHNIUM 220
- HAMMER
- KAMIKAZE
- RANDOM + CONCERN CHAOS
- WLODEK BLACK
- ZX NET
- ANDY DAVIS & ALCHEMIST RESEARCH 
- FBI
- TFF TEAM
- TANOD
- PROXIUM
- REAL MASTERS 
- FACTOR6
- AVALON 
- CLAW (hi DC PAK!! :-) ) 
- VIRTUAL BROTHERS
- ALIOTH (hmmmm, maybe not really ZX-group, but real Speccy-freakz)
- SPECCY BOYZ (hi, SS!! :-) ) 
- MB-MANIAX
- BIT MUNCHERS 
- GLOBAL CORPORATION
- VAV & KSA
- GALAXY INC.
- WARLOCKS
- IMPERIO from BOWER GROUP + HOG 
- STYLE
- BRAINWAVE (Hullo, Megus)
- ANTARES
- SYNDROME
- EXPIRT
- E.S.A. 
- ETERNITY INDUSTRY aka PLACEBO
- DIE KRUPPS
- JAREK ADAMSKI
- EQUINOX
- CHILLZ
- E.S.I. 
- TIM FOLLIN
- ADRIANO
- GASMAN
- z00m
- T.C.G.
- CI5
- TRIXS
- SERZH
- RUSKEJ
- KARATE
- POKE
- OZZYOSS
- ANDY BROWN
- DEPECHE CODE
- ACCEPT CORP. 
- KRAP GANG
- SHIRU
- SPECIAL TEAM
- THORGAL & SZNINKIEL 
- ALONE CODER
- SHREK
- POL
- 4D
- JAD
- ZERO TEAM (Ellvis, Mike)
- FIKEE
- WIXET
- PATISONERS
- NEWART
- BioTech
- n-Discovery
- RET
- Panda/Rush
- Slider/Rush
- AleXoft
- Nitro
- AY-RIDERS :) 
- Mister Beep ;) 
- Mandala Breakers
- AER
- Triumph
- Entire Group
- MGN Group
- Mayhem
- Delirium Tremens
- Togyaf
- AAA Band
- Target
- GriV
- Mr. Plop and Dr. Kvetch 
- Softlight 
- Omega Hackers Group
- SG-Team 
- Piesiu
- XXL
- Alco 
- gbg
- LVD
- CHRV
- Savelij
- Breeze & Fishbone Crew
- MMA
- Olly_bfox
- Fenomen
- Total Computer Gang 
- Debris
- Militia
- Simbols
- Perspective
- Invaders8 
- Innercore Group
- AY LAND
- Halloween
- Inward
- Tpolm
- Cez GS
- CNG Soft 
- Time Keeper
- OSG Omega Software GFX
- Hackerz Design Software
- Siberian Group
- Progress
- Eye-Q
- Organizm
- ZILOG
- OCA
- red triangle 
- Colour of Magic
- Zeitwot Team
- Master Home Computers Group
- Rafa? Miazga
- DELY
- Timmy
- CodeNameV
- Binman
- Bobs
- Jonathan Cauldwell
- Mulder
- Ccowley
- Cheveron
- naTrent
- Habib
- Vavrzon
- FrankT
- irrlichtproject
- Regent Software
- Dataputer
- Jaan Viira
- Doctor V/Dark Lords
- SSC-Soft
- Alfa Soft
- Mr Incognito
- Pavel Nikitin
- Janosy, Kozma, Hegedus
- Theo Devil
- Thorin
- PJB
- Danish Cracking Department
- M&Z Maciej Zielinski
- JardaSoft
- thesuper
- Chezron Software
- Castor Cracking Group
- Max Hedrom
- Fabrixoft
- Rich Swann


                     ...and **many** other people!!

Ludzie, jesli o kims zapomnialem lub przekrecilem jakas xywke, to mozecie mnie
zabic. Staralem sie wymienic wszystkich tych, ktorzy w jakis sposob przyczyni-
li sie do propagowania ZX-SPECTRUM.
 

                                            Pozdrawiam!!!!!!!!
                                          YERZMYEY/HOOY-PROGRAM

                          
                                       e'mail: yerzmyey@interia.pl

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  ZBYLUT.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  ZBYLUT.DSK, Diskfile for emulators, to start the game, type *RUN"ZBRUN"

AtoMMC version:

  ZBRUN  = Basic introscreen
  ZBSCR  = Titlescreen
  ZBCODE = Gamecode

  To start the game, type: *ZBRUN

