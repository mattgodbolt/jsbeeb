MORITZ - THE DOG THAT CAUGHT THE CAR

It was a day of celebration in the forest. The party was in full swing and all the forest animals were drinking themselves into oblivion with great gusto. Moritz had been drinking heavily all morning (since around 6am) and stumbled off into a quieter area to relieve himself. He cocked his leg, stumbling somewhat, and took some time to reflect on this fantastic day whilst liberally soaking an anthill with a large quantity of urine. He then stumbled back to join his friends.

Nothing. No-one. Everyone was gone.
"Where are they?" thought Moritz to himself.
"Hello? Anyone? Yes, you can all come out now!" he cried "And I don't mean in 'that' way. I'm not insinuating anything. Come on, show yourselves!" he continued.
Silence. Not even a bird tweeted. He sat down and began to whine, mournfully.
Strangely, his whining began to mingle with a sound drifting towards him from the far distance. Then, without warning, a blinding ball of light appeared in front of him. The noise got extremely loud and he put his paws over his eyes then, suddenly, it stopped. When he opened his eyes he saw a blue telephone box in front of him. He looked down absent mindedly at a pork pie resting nearby and began eating it. When he'd finished he wandered over to the blue box. It said "Police" on the top.
"Has everyone been arrested?" He wondered, pushing himself through the slightly open door to investigate.

He saw a shadow moving in the darkness within, illuminated by the shaft of light coming from the barely open door.
"Hello, mate, what's going on?" He asked.

"My name is Sam Tyler. I had an accident and woke up in 1973. I think I might be mad. Either that or I'm dead. Or am in a coma?" replied the shape in a dull, monotone voice.

"How would I know?" said Moritz

"Well, whatever's happened it feels like I'm now on a different planet. Dogs don't talk where I'm from. If I can figure out how I got here then maybe I can get home" Sam continued.

"Okay, um... Anyway, I'm Moritz, pleased to meet you. Is there a toilet in here, by any chance?" Moritz looked around inquisitively.

His eyes had now become accustomed somewhat to the dark and he could see that this 'Sam Tyler' had a vacant, cold expression, his eyes glazed over.

"My name is Sam Tyler. I had an accident and woke up...." Sam started again and continued droning on. Moritz began looking for a toilet. After some time sniffing around he gathered that there was no such thing. Sam had been repeating the same thing this whole time, as if on some kind of loop. After some time he slumped forwards and fell silent.
Moritz felt a little scared but, despite this, decided to cock his leg to urinate in a dark corner of the phone box.

Suddenly and without warning a commanding yet soft voice boomed out from nowhere

"This is not a toilet, Moritz. You could be forgiven for thinking so, being as this 'Sam' character has soiled himself multiple times, but I can assure you it is not." It intoned.

"Ah, okay, sorry" Said Moritz, cowering somewhat, his ears flat to his head.

"I, Moritz, am the tenth Doctor and you are our last hope."

"I must have missed the other nine" Said Moritz "And how do you know my name?" He continued.

"I've been watching you, Moritz. Not in 'that' kind of way, so don't be alarmed. I watch everyone. Note the emphasis on the word 'watch', for I am, in point of fact, a time lord"

Moritz sat down, his tail wagging slightly and his head turning slightly to the side. He replied to the disembodied voice.

"Oh, okay, I know who you are. Doctor Who. You were in the doldrums for a while but now you are on television again. You have some kind of pocket penis"

"My sonic screwdriver!" The doctor replied

"Yes, that's it. Strange thing. Something of a MacGuffin. Yes, I know who you are" Said Moritz

"Well, I suppose everyone does" Said the Doctor "Except for those weirdos over at 'planeta sinclair' but they're an odd bunch. All left handed, you see. Late developers, too. Anyway, forget that. Oh, also, try and keep your voice down or you'll wake Sam and he'll start his bullshit all over again" Replied the Doctor

"You're the one who's being loud, you should keep quiet!" Said Moritz

"I'll ask the questions" Came the reply

"But that wasn't a question" Said Moritz, somewhat confused.
"Exactly" Said the Doctor, wryly

"What does that even mean?" Continued Moritz

"More questions, hmmm" Said the Doctor. Moritz could hear his sonic screwdriver beeping away.
From nowhere a new voice suddenly spoke in sleepy, soft feminine tones.
"Come back to bed, I'm cold" it said

"Is that Billie Piper?" Asked Morris, straining his eyes in the direction the voice came from but seeing nothing but inky darkness.

"No" replied the Doctor "I'm... I'm totally alone" his voice wavered slightly

"Was that a lie?" Asked Moritz

"Ah, questions questions questions. Would Gallileo have gotten anywhere if he was constantly assailed with questions? Why this, Why that? Would Da Vinci have managed to take multiple young men back to his squalid venetian garret if they'd been preoccupied with asking what was going to happen when they got there?" The Doctor replied.

"Christ" Said Moritz "Look, I'm getting a headache. I've been drinking since 6am. Is there any real point to all of this? Can I go now?"

"No, Moritz, sadly not" Said the Doctor "You are, unfortunately, trapped inside my new Tardis which, in case you hadn't noticed, actually looks like a giant ZX UNO on the inside"

Moritz sighed. The Doctor continued

"Anyway, The door is buggered and only lets things in, not out. Great for parties but, as you've discovered, not that useful in terms of sanitation. So, as you're trapped here we might as well put you to some use. How does saving your friends sound ?"

"My friends?" Moritz's ears popped up "Why? Where are they?"

"They're locked up inside a bastion of great evil at the other end of the galaxy. I'm not really sure why. Narrative purposes, I presume. Anyway, if you choose to accept the quest your very life will be in peril, Moritz. Can they count on you?"

Moritz huffed.

"Look, I'm shitfaced and really tired. Plus I'm not exactly hero material. My primary interests are eating, drinking and going to the toilet. I've never really gone in for going to the other side of the galaxy to bust a gaggle of **** up idiots out of some heavily guarded space prison. Not really my thing" He said

"Well" Said the doctor "That's as maybe, but you're not going anywhere and you don't want to wind up like this stupid **** over here" He continued "Oh, sorry, you can't see me, can you. Well, I'm pointing at Sam, just so you know. He's anything but wise. In fact, he's a complete arsehole and I wish he'd never wandered in here"

"Right, whatever, if I'm not getting out of here we might as well do something" Replied Moritz.
There was a strange electronic chirping noise

"Was that your sonic screwdriver?" Asked Moritz

"What did I tell you about questions?" Came the reply

"Oh for fucks sakes..." Moritz grumbled

"Anyway, there are loads of floppy disks scattered around the place in here. You'll have to find them and boot them up into the system in order to figure out how to fly this thing. I'm heavily constipated so pretty indisposed at the moment, hence being unable to be there in person. I'm talking to you from my interdimensional toilet, if you must know. So, really, everything is in your hands, Moritz" Said the Doctor

"Seriously? Mate, the ZX UNO doesn't even take floppy discs. What the **** are you talking about?"

"That was a question again, Moritz. I've warned you about them now for the third time. So, I've told you what to do. I'm stuck here on the toilet and it feels like I'm about to give birth out of my arsehole to an angry brown cabbage so, really, I've bigger fish to fry wherein the word "fish" equates to "****" and "fry" would be replaced with "do", savvy? Find the floppy discs and something or other should happen. I'm pretty sure, 99%. Well, maybe 50% but, still, it's better odds than wandering around here in the dark urinating yourself to death" The Doctor replied "Have a little jostle with the controls and you should be able to navigate your way to some dimension or other, then simply render a portal to get outside and collect the floppys. However, bear in mind that this IS a quantum device and when you are outside you're still actually inside so you've not actually escaped, it's more like reality has escaped into you, if you understand? You possibly don't, but you will. Besides, you've got 42 lives so what does it matter"

"42 lives?!" Exclaimed Morris

"Yes, the answer to everything and all that. Deep thought. Are you sure you're not from 'Placenta Sink Lair'? You seem remarkably ill educated" Said the Doctor

"Look, I'm going to do your bullshit quest so can we cool it with the personal insults?" Said Moritz, sounding annoyed

"Okay, okay. Be like that. No need to be cruel, I'm just trying to help. Honestly, you'd think I'd asked you to go and live inside your own colon. Coincidentally, I've been somewhere where the resident life forms do just that. Anyway, I need to go as I'll need my full concentration and perhaps the use of my sonic screwdriver, or 'pocket penis' as you so ineloquently call it, to rid myself of this bowling ball of dung that's currently dominating my entire existence. Goodbye and good luck!"

Moritz huffed again.

All of a sudden lights started blinking on all around him and he could see all kinds of consoles, even the fabled vega+ put in an appearance. He remembered the Doctors words and reasoned that this must have been from another dimension entirely, folding itself into his own to showcase a reality wherein a jaded chess 'champion', his moronic, lying daughter and possibly the most hated man on the internet actually got their collective **** together to produce something. He rubbed his paws over his eyes. The Vega+ was gone and had become a shifting mass of gears and coils. The words "Push here" and "Do not press" mixed and mingled in a million different realities, all pointing at the same time to the visual maze of dials and buttons hovering in front of him.

Moritz looked back into the corner of the Tardis where he'd urinated. It was now fully illuminated, the lights dancing and reflecting on the surface of the thin puddle of ****.

"**** it" He thought, and started stabbing at buttons randomly.

The ship lurched and spun but his chubby little legs stayed his swaying, sausage like body as he continued pushing at things with his nose and turning levers and cogs with his teeth.

A radio cackled into life

"This is Pavel Chekov from the USS Enterprise can you please stop this, you have smashed into our lower deck several times now and as our resident fake Scotsman informs me, we 'canna tak much mair o this'. Please stop or our, arguably xenophobic, Captain will be forced to open fire" It said

Moritz thought for a moment or two then replied "Look, mate, you're dead, I saw it on the news. You got squashed against a fence post by a car or something like that. Someone who'd beefed Imogen Poots COULD be viewed as the voice of authority but not when his guts have been squeezed out his mouth by a Jeep Grand Cherokee in an incident that, according to the dealership, was the direct result of his own misuse of the aforesaid vehicle"

The radio hissed and crackled again

"I didn't beef her. We were just good friends. My publicist just said it would be good for me to be seen, you know, with more females. Questions were starting to be asked. Losing signal, Uhuru can you f....fin........ssspzzzzzzzzzzz..........cffffffffffffff"

The signal faded into white noise as Moritz continued pulling at the various controls in front of him. He was quite enjoying this now. It was a bit like being on "The waltzers", a well known fairground ride, only without the omnipotent menace of the usual gypsies positioned around the queue, pickpocketing everyone with reckless abandon.

A loud noise like a creaking old door tore through the Tardis and the lights flashed on and off.

"Chewbacca, do you read me?" Said hack horror author Stephen King

"AAAAAAArggrgahgahahahhahaaaauuuuuuuuunnnngggg" Came the reply

"I'll take that as a yes, then. Good." Came King's wry and self aggrandising reply.

The inside of the Tardis was suddenly bathed in a luminous light that shifted quickly between purple and green

"Phone Home. ET. Phone Home"

Moritz felt a lot of pressure in his head, as if all of these stereotypical sci-fi characters were at once existing within him while he was simultaneously existing throughout the entire galaxy in all places and at all times. He thought about toileting himself. Looking up at a sign on the wall that read "Tardis" he noticed that it would shimmer from time to time and morph into the word "Turdis". Presumably in some other far off dimension, or multiples thereof, this was in fact a giant, quantum toilet. The thought filled him with joy and, at the same time, a slight feeling of dread.

"What if there's loads of interdimensional shitpiss in my mouth at the moment, in multiple dimensions?" he thought. His head began to hurt again as he tried to put the, possibly imagined, taste of excretia to the back of his tiny mind. The wheels before him were not going to turn on their own, nor would the buttons push themselves.

The Doctors familiar voice boomed out once more

"Moritz, hello, sorry about earlier, it's the Doctor again. I've done my **** and I can tell you a little more about where you're going"

Moritz thought again about Sam being awoken but looked over to where he'd been lying and noticed he'd now, in all the movement and commotion of interplanetary/dimensional travel, slumped over fully and was lying along the floor. His head and hair were resting in Moritz's earlier urination.

"Oh, well" he thought to himself "At least there's a dimension where his hair ISN'T full of ****"

"Right, Moritz, I've got a little more info on where we're going. You need to follow the yellow brick road" Said the Doctor

"Do I look like **** Tonto to you, mate? What are you, nine years old?"

"That's another two questions, Moritz. Questions require answers and answers require more questions so I'm going to just choose to completely ignore them. As I said, yellow brick road." The Doctor continued "Now, you may at times be beset by witches and/or hovering, ridiculous looking monkeys that do seem to have a penchant for masturbating. It's normal. That's just something monkeys do. Have you seen 'Monkey rapes frog' on youtube, for example?"

"NO" Moritz replied, holding on for his life as the Tardis twisted hard to the left. Sam rolled past him across the floor, his head thudding against the far wall.

"Oh, well, never mind. Look it up some time. It's breathtaking. So, anyway, follow the yellow brick road and you'll reach a big green castle. This all presumes, of course, that you've not been waylaid by a troupe of flying apes and their wanton displays of onanism. Either that or a witch has got you. Still, if that happens you can simply drop a house on her. It's worked in the past. And, of course, by 'the past' I also mean 'the future' - if you follow me"

Moritz said nothing

"So, you'll find some toy soldiers in the castle and, hm, maybe some star wars stuff, do you like star wars?"

"Love it" Said Moritz through gritted teeth, his mouth chomping down on a large brass wheel and hauling it to the right.
"Okay, so, yes, there's star wars stuff. Then a garden. Or maybe a graveyard. Same thing really, I suppose. Probably. Depends how you look at it. Semantics. Yes, semantics. Anyway, after that there's a robot. Find a pistol and shoot him. Should be simple. Could be simple, anyway. Also, 42 lives and all that. Then, hm, some cloud walking. I think Michael Jackson did it in one of his videos. Or his film. No, sorry, that was the moon. Actually, it's probably best to stay away from 'Wacko' as an example of anything, I suppose, although I can confirm there IS a dimension wherein he's fat, married and has 3 children, none of which have experienced anything remotely inappropriate in terms of conduct from their doting father - or their mother, who is Kelly off of 'Breakdance'. Probably. Actually that's maybe conjecture. It might have been 'Ozone', not 'Wacko'. Hard to tell, even though one of them looks more puerto rican close up. I was far away" Said the Doctor "Besides, time waits for no man and that includes me only, well, I'm not a man and technically it does actually wait for me so, well, scratch that last statement. I'm off again but I will return. Maybe. If I have time. Good luck with the Oz/cloudjumping stuff and definitely resist the urge to make lascivious advances on minors. Or is that miners? Stay clear of either, I'd say. Savile was a miner at one point. Used to leave the pits at the end of each day white as a sheet. Not right, that, is it? Well, unless you're mining on Quatanium 9, where the pits all contain white dogshit that the 9'ers as they're known use to fuel pretty much every device on the planet. Interesting place, that, if a little smelly"

A million miles away in another dimension, the Doctor materialised.
"Doctor, you didn't tell him the truth, did you?" Came a feminine voice from beyond shifting banks of vermillion mist

"Well, it's all relative, isn't it. I told him the World of Spectrum truth. Now, that's not the truth at all, as we know, but, still. It's truth to one man and, as they say, one mans truth is transparent bullshit to the rest of humanity, no?" He replied. The sonic screwdriver chirped in agreement.

Hours later, Moritz was furious.

"That doctor is a massive arsehole. Oz was a shithole, everyone was trying to kill me or sing at me. Intolerable **** nonsense and every time I sat down for a **** I'd be encircled by flying apes all pulling at their willies and laughing. Even Don Cheadle turned up in a **** costume. I don't even know what he was meant to be. He looked like a **** ant. They'd have been better getting the police chief from 'The Wire' to play that role. At least he wouldn't have needed all the ridiculous make up Cheadle was wearing." He moaned to himself "Jumping on clouds that didn't support my weight and having to clamber around on a tie fighter. This is ****. My head is pounding and I really need another drink. Or a pork pie. I'd kill for a pork pie."

"Never mind, Captain Moritz, the universe is full of strange and wonderful things and, for the most part, I've had my tongue down ALL their throats, and elsewhere, too!" Came a caddish, annoying, faux American accent from behind him

"Jesus, you startled me" Shouted Moritz

"Jesus? Me, no" A row of perfectly annoying Hollywood style teeth broke into a smile "But it'd be interesting, right? Ol' metrosexual chocolate knob as the personification of gods only son, sent to Earth to turn willing men - around against the wall!" He guffawed and threw his hair back in an irritating manner

"Who the **** are you and how did you get in here?" Asked Moritz

"Me? Jack Harkness. Torchwood. Pleased to meet you" He extended a leather gloved hand towards Moritz's paw, then retracted it "Pleased to meet you, indeed. I'm basically an offshoot from Doctor Who, well, not personally, but my show is. Then I turned up in arrow, laughably, would you believe it, as the main bad guy. I'm actually from Glasgow but I speak in this ridiculous, faux American accent so that no-one realises I'm just a talentless ned. Do you know what a ned is?" Jack continued

"NO" Said Moritz

"Well, it's a long story, basically a child from Glasgow who eats a kilo of sugar a day, is in court for housebreaking before he's 3 and is, more often than not, the product of incest. Anyway, my friends call me chocolate knob"

"What? What the **** are you talking about?" Stammered Moritz, paying more attention to the controls than the leather trenchcoat wearing cretin standing beside him.

"Well, I've got a birthmark on my penis, or my "wullie" as we'd say in Glasgow. It's dark brown so I'm known on set and to my friends, whom I could count on the fingers of one hand - If I didn't have any fingers, as chocolate knob" Said Jack, laughing in a very over the top, stage school manner.

Moritz remained stony faced.

"So, what brought you out here?" Asked Chocolate knob
"Out where?" replied Moritz

"Well, out into these public toilets? It's only usually myself and my male friends who lurk in here. George Michael was in a while back. Oh, and Kevin Spacey. I've never seen a dog in here, though. What are you here for, a spot of DOGGING?" Again Jack burst into outrageous, over the top laughter whilst Moritz remained po faced.

Moritz looked around. It was true. Somehow he was inside what looked like a British public toilet. The kind one might find on Hampstead heath. The tardis seemed to be half in, half out of the wall in front of him, shimmering and glitching. A pile of Boy George CD's to the left of it whilst a policeman patrolled endlessly to the right, seemingly caught in some kind of ever unfolding time loop.

"Oh, don't mind him" Said Jack, gesturing towards the policeman "He's in a causality loop. He can't see us, or do anything about what we get up to!"

"What do you mean 'what we get up to'?" Asked Moritz

"Oh, I wasn't meaning you and I. I mean, I'm up for anything, my stage school background and frequent visits to the GUM clinic should tell you that but I do draw the line at animals, especially ones in your kind of state" Jack said, pulling a stage school face that telegraphed "repulsion" as he looked at Moritz's bottom

Moritz noticed he'd shat himself
"Don't mind about that" Said Jack "It's a by product of this whole time travel lark. Happens to me all the time, although I've a manservant to clean it all up for me - which I do relish, by the way"

Moritz huffed and made his way back towards the Tardis

"No, wait, don't" Shouted Jack in his trademark stage school style

Moritz crossed the threshold. All was dark save for a sliver of light from the door behind him, illuminating a figure slumped against the far wall.

""My name is Sam Tyler. I had an accident and woke up in 1973. I think I might be mad. Either that or I'm dead. Or in a coma?" it said

"Fucks sakes..." thought Moritz to himself.

Meanwhile, far away behind veils of interdimensional mist...

"Doctor, you've really been a bit of a prick about all this. Is Moritz in danger?" Asked the same femine voice
"Danger? No. Well, yes. But no. Quite possibly no, but with a little bit of yes. He's a dog. Dogs can take care of themselves. Anyway, there's only one thing that dogs are afraid of and there's none of them anywhere near him. Not currently, anyway. Not as far as I'm aware of, as far as I konw. Probably." Said the doctor, pulling out his sonic screwdriver. It chirped and beeped "No, no vaccuum cleaners on that particular journey. At all. No need to fear"

And, with that, he buried himself deep in Billy Pipers voluminous bottom a million times in a million different dimensions at once.

"Oh, Doctor, so SAUCY!" Said Barbara Windsor, 90.

At the exact same moment, in a completely different place.

Baker street 221B

"Mrs Hudson, we have a guest. Can you please go to Mr Cropper the butcher and return with one of his finest bones? Thank you"

"A bone, Mr Holmes? And what guest?"

"A dog" Replied Sherlock.

Watson did that thing with his eyebrows that he does in every **** role he ever gets, from the office to the hobbit.

"A dog, Holmes?" He asked, quizically

"Yes, Watson, a dog. A mammal. Four paws. Shits outdoors. Mostly. You know, a mammal, like me, only it looks markedly less like a bizarre, stretched pig and hasn't cack handedly taken over from the vastly superior Alan Rickman as Hollywood's 'go to' English chap now that he's dead"

"A dead dog?" Said Mrs Hudson

"No, Rickman. Anyway, the butcher shall not wait, Mrs Hudson. I'd warrant Mr Cropper has better things to do than waiting around to provide you with his 'offaly' good cast offs so, off you pop, tempus fugit"

"That sounds dangerous, Holmes" Said Watson, doing that **** thing with his eyebrows again.

"It's basic Latin, Watson. Surely a man such as yourself was required to have a basic appraisal of Latin in order to transition from student to practitioner, no?" Said Holmes, whilst using an antiquated looking perfume puffer to blow a large quantity of cocaine up his own arsehole. "Now where's the rest of it?" He muttered, going through his desk drawers in an increasingly agitated manner.

"I'm only an actor, Holmes, and not a very good one, although arguably I was moderately endearing in the BBC's 'micro men'" Watson replied

"Never heard of it" Barked Holmes, arrogantly, striding around his office making "Whoosh" noises and twirling a thin walking cane in his hand, occasionally hammering it down with terrific force on the pile of cushions next to Watson on the sofa.

"See that?" He asked Watson "Imagine what that would **** do to Moriarties face" He said, exhaling hard and aggressively through clenched teeth and bringing down the cane once more.

Watson shifted uncomfortably in his chair and did that **** thing with his eyebrows. Again.

Mrs Hudson stumbled back through the front door, about 90 vaccuum cleaners under her arms.

"What on Earth have you got there, woman?" Barked Holmes, blinking and sniffing as his head jerked, erratically

"Well, this place isn't going to clean itself master Holmes and these were on special at Argos. I swapped them for a massive lump of that powder that you keep in your desk. It just looked like a pile of old dust so I presumed you didn't want it."

Holmes fixed her with an aggressive, icy stare and advanced towards her, cane held aloft.

Elsewhere in the galaxy, the Doctor and his assistant continued their conversation

"Doctor?"

"I am busy. Doing a ****. As you well know. The door is closed and the red 'danger' light is on. You know what that means"

"Yes, I know, but, really, is this a suitable storyline for a ZX Spectrum game. I mean, really, this doesn't seem to relate to ANYTHING"

"**** off, Billie"

THE END

Controls:
  O   - Left
  P   - Right
SPACE - Jump
Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  MORITZ.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  MORITZ.DSK, Diskfile for emulators, to start the game, type *RUN"MORUN"

AtoMMC version:

  MORUN  = Basic introscreen
  MOSCR  = Titlescreen
  MOCODE = Gamecode

  To start the game, type: *MORUN

