Stripping Penelope:
-------------------

THE GAME

This is an action arcade/platform game for Spectrum 48K (without music)/128K (with AY music) made using AGDX (a modified version of Arcade Game Designer 4.7) and AGDMusicizer II.
The main character - the player - is Fred Stallion, a womanizer.
He goes to a bar and tries to hitch Penelope.
But she call him a loser and made him a propose: she will strip one part of her clothes for each gift he offers her.

PLAYING THE GAME

The game has 12 playable rooms (the Penelope screen don't count).

The objective of the game is to Penelope become totally naked to have sex with her.
For that, Fred has to pick up the 5 pieces of clothes that flashing in the screen (glasses, top shirt, skirt, bra and underpants) and then get the random gift (flashing) to give to Penelope.
Penelope will strip one piece of clothe (well... Fred thinks it so...) for each gift Fred brings to her.

In the last level, Fred have to collect the 5 combined female and male symbols and then (and finally) catching a nude flashing Penelope.
Fred can also catch the flashing Penelope's face that floats in some screens. Each of it gives Fred a latter from the word PENELOPE. Having the entire name, the player earns an extra life.
In the gameplay screens, Fred will see some kind of joystick levers. Pushing them will release some platfoms that allows the player reach some places.
It the bottom of the screen are the number of lives, the word "STRIPPING" and as the player catches the floating flashing face of Penelope, the word "PENELOPE", and we can see a kind of shield.

In some gameplay screens, Fred will see some shields with a man drewned. Picking up each one will increase the time of immunity in the final level.
In the final level, the player have 2 boxes with the player drewned. Touching one of that boxes, the player have temporary imunnity to wander without being catched and killed by the though guys (that feezes in that time). Temporarily!
Fred will find some parachutes in some screens. Touching them will make Fred descend and access in some places that cannot reach before.
In some levels, Fred can hang from hanging bars and progress clinging to them.

The work will not be easy, so Fred will must avoid:

dealdy spikes
deadly flames
slimy worms and other crawler things
deadly ice skate
drones
flying secutity cameras
bolting / thundering clouds
bar steel ballons
sharp cutting blades
dangerous air ballons
flashing red diamonds
There are 2 extra lives that the Fred can pick up (plus the extra life when having the word "PENELOPE").

The player starts with 9 lives.
Losing all means GAME OVER.

CONTROLS

The character can be moved only using Keyboard.

Q for UP
A for Down
O for LEFT
P for RIGHT
SPACE for JUMP

CREDITS

Game made by Jaime Grilo using:
- Arcade Game Designer eXpert (AGDX) by AGDLabs (a mod version of Arcade Game Designer (AGD) 4.7 by Jonathan Cauldwell)
- AGDMusicizer II by David Saphier
Loading screen by Jaime Grilo and José Silva
Music by DJ AVO
Font (Vertigo) by Damien Guard
Game tested by André Luna Leão

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  PENELOPECSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  PENELOPE.DSK, Diskfile for emulators, to start the game, type *RUN"PERUN"

AtoMMC version:

  PERUN  = Basic introscreen
  PESCR  = Titlescreen
  PECODE = Gamecode

  To start the game, type: *PERUN

