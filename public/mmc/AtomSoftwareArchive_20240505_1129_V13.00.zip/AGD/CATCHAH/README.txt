Catch a Hare:
-------------

I dedicate this game to my dear wife, for her great patience with my passion ... �Have you ever hunted a hare?� If yes, then you probably know how it is not easy ...
And if there is still no, then right now, you should try yourself in this business ..
So...... You are a real hunter!
At your disposal, eight highly trained hunting dogs.
With the help of these dogs, you have to catch a hare.
During the hunt you need to skillfully place the dogs around a hare, otherwise he will easily outwit you.
The outcome of the game depends on your hunting skills.

Purpose of the game:
If you wish, you can define a goal for yourself.

1. Catch the hare.
2. Keep the hare on the field for as long as possible.
3. To drive a hare into a trap.

Controls:

Keyboard (opqa / sp) 
Kempston joystick 
Sinclair joystick

If the Kempston joystick is selected, then the fire button and the space bar are
same.

Play style

You can choose the appropriate hunting style that you arranges.

CLASSIC:
--------
With the help of hunting dogs, catch a hare on the field, or hold as long as possible.

TIP:
Try to drive the hare where there are obstacles for him.
So much easier to catch him.

FREE:
-----
Same as the classic, just hunting in nature ...

TIP:
Dogs cannot catch a hare in the bushes, so try not to get to the bushes.

CHASE:
------
It is necessary for dogs to drive the hare from left to right into a trap, or just catch or hold on the field ... If the hare ran away from you, or you catch him, the game will start with places where the chase begins.

TIP:
Remember! You only have eight dogs! Use them correctly !!!
The arrow in the lower right corner shows where to drive the hare.

Difficulty:
According to your strength, you can choose the level of difficulty of the game.
Keep in mind. Not always an easy level, it is convenient and easy ...
It all depends on the choice of style of play.

EASY:
The hare moves only diagonally. The level of intelligence hare low.

NORMAL:
The hare moves in all directions. The level of intelligence hare average.

HARD:
The hare moves in all directions. The level of intelligence hare tall.

Fast hare
In this mode, the hare will try to escape, as soon as possible, not waiting for your action. Try to get the dogs ahead of the hare.
Also, Fast hare mode is activated after a long and happy hunting.

PLAY:
Having chosen the necessary settings, start the game.

HELP:
Help in pictures.

ADDITIONALLY:

SCORE:
Arrange a tournament with friends. Earn points !!!
For each dog exposed you get ten points. 
The longer you hold the hare on the field, the more points you get.
For each caught hare, you earn a thousand points.
In chase style, if the hare is trapped, you will get three thousands of points.

Hare tricks
Hare, all the time strives to run away from you, using some tricks ...

a) Runs around, luring all your dogs.
b) Can confuse dogs and they will lose track.

HARE WEAKNESS
In some situations, the hare may panic and not immediately find way, and maybe even give up. Take advantage of his panic.

OPPORTUNITIES OF THE HUNTER
You can always call off your dogs and let go of the hare.
Make it easy. When the hare is caught he panics. At this time, by moving the cursor in
any place from the starting point, you recall the dogs.
If you caught a hare, and you still have free dogs, you need every time after moving the cursor,
put dogs in an arbitrary place until the last dog is exposed.
It is necessary in the pursuit style to earn as much as possible. more points and at the same time do not start the chase from the very beginning.

TIP:
In the free mode, expose the remaining dogs extremely quickly, otherwise, you just do not have time to withdraw them. And here, in the Fast hare,
You can not rush.

Thanks:

Jonathan Cauldwell, AAA, LAV, ZX.PK.ru!
SPECIAL THANKS TO BLADE !!!!!
Play the guys for health!
Good luck everyone!!!
Spectrum FOREVER !!!

Kashkarov Alexey (kas29) 2014 http://newgamezx.jimdo.com/

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  CATCHAHARE.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  CATCHAHARE.DSK, Diskfile for emulators, to start the game, type *RUN"CHRUN"

AtoMMC version:

  CHRUN  = Basic introscreen
  CHSCR  = Titlescreen
  CHCODE = Gamecode

  To start the game, type: *CHRUN

