The Hair-Raising Adventures of MR HAIR:
---------------------------------------

Mr Hair is on a Quest of a lifetime as the battle for freedom rages on!
Race across trackless voids to unknown and countless worlds where you will enter into the heart of darkness. 
You will face many foul monstrosities, crazy creatures and aliens from a thousand worlds. Your destiny relies upon you not being swallowed by the belly of the beast and escaping to freedom!
Unfortunately your path will not be an easy one, being blocked by cunning powerful forces beyond your imagination. 
His Fate Lies in Your Hands!
Welcome to the Hair-Raising Adventures of MR HAIR

CONTROLS:

KEMPSTON JOYSTICK
SINCLAIR JOYSTICK
 KEYBOARD 
O - LEFT   P - RIGHT 
Q - UP     A - DOWN 
 SPACE - JUMP 

PHYSICAL COPY ALSO AVAILABLE HERE: https://www.bitmapsoft.co.uk/

This game is Free but if you would like to make a small Donation please could you give it to :
http://www.justgiving.com/southendcysticfibrosisassociation
A very important charity close to all our hearts, thank you  :-)
http://www.southend-cfa.org.uk/

REVIEW:
http://www.indieretronews.com/2019/12/the-hair-raising-adventures-of-mr-hair.html?m=1

CREDITS:
An Original Game, Coding, Design & Graphics by Lee Chops Stevenson
128k Spectrum Music by Pedro Pimenta
https://jumperror.wordpress.com/?fbclid=IwAR1MM9rnuLJ4I0xJ-5CHu-mcAY9atgw4w7uUC1...

Loading Screen by Andy Green
https://www.facebook.com/AndyGreenPixelArt/
https://twitter.com/AndyMGreen68

AGDX  BY ALLAN TURVEY
AGD  BY JONATHAN CAULDWELL

Atom version done by Kees van Oss.

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 8 KB video RAM (#8000-#9FFF)
- Joystick connected to keyboard matrix (Optional)
- Joystick connected to PORTB AtoMMC interface (Optional)

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
Tape/Disk and AtoMMC version:
===================================================================

Tape version:

  MRHAIRADV.CSW, Tapefile for Atomulator, to start the game, type: *RUN"AGD"

Disk version:

  MRHAIRADV.DSK, Diskfile for emulators, to start the game, type *RUN"MHARUN"

AtoMMC version:

  MHARUN  = Basic introscreen
  MHASCR  = Titlescreen
  MHACODE = Gamecode

  To start the game, type: *MHARUN

